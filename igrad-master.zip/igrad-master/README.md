# igrad
Software Development Capstone Project

#Testing 
Leveraging C# Unit testing within the IGrad.Tests project.
Imported Selenium Web packages to leverage UI testing via scripting.
