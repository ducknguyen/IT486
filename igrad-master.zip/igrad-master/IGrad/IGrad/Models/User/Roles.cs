﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IGrad.Models.User
{
    public class Roles
    {
        public bool isUser { get; set; }
        public bool isAdmin { get; set; }
        public bool isStudent { get; set; }
    }
}