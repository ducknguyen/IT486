﻿window.onbeforeunload = function () {
    // add check if required fields have been filled or not 
    // return "You have not finish the form";
};