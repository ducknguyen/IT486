Tests:
1. Verify Home page exists
2. Verify About page exists
3. Verify Contact Page exists
4. Verify New Application Page exists
5. Verify Homepage Link exists and is clickable - Goes to correct Page
